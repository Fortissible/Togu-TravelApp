package com.example.togutravelapp.data

data class LoginResponse(
	val password: String,
	val email: String
)

