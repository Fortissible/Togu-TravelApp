package com.example.togutravelapp.data

data class DetailObjModel(
    val title: String,
    val desc: String,
    val locTitle: String,
    val loc: String
)
