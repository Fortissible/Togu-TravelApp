# Togu-TravelApp
This project aims to develop the preservation of cultural tourism and tour 
guides in the Bandung area. We divide the task into several parts, 
every 3 days we will discuss and show each other progress and results achieved. 
Work results are determined according to each Learning Path. 
The expected end result is the Minimum Viable Product of this Travel App.

<p align="center">
  <img src="https://github.com/wildanfajri1alfarabi/ToguTravelApp/blob/master/TOGU.png" width="480" title="Togu Travel App">
</p>
<p align="center"><b>Togu Travel App</b></p>

## Application Development Repository
Welcome to Togu Travel App development repository
